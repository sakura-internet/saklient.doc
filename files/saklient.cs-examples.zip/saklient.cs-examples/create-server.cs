using System;
using System.Collections.Generic;
using System.Threading;
using Saklient.Cloud;
using Saklient.Cloud.Resources;

class CreateServerExample {
 static void Main(string[] args) {
  
  // settings
  string token = args[0];
  string secret = args[1];
  string zone = args[2];
  string name = "saklient demo";
  string description = "saklient demo";
  string tag = "saklient-test";
  int cpu = 1;
  int mem = 2;
  string hostName = "saklient-test";
  string password = "C8#mf92mp!*s";
  string sshPublicKey = "ssh-rsa AAAA...";
  
  // authorize
  API api = API.Authorize(token,secret,zone);
  
  
  // search archives
  Console.WriteLine("searching archives");
  List<Archive> archives = api.Archive
    .WithNameLike("CentOS 6.5 64bit")
    .WithSizeGib(20)
    .WithSharedScope()
    .Limit(1)
    .Find();
  Archive archive = archives[0];
  
  // search scripts
  Console.WriteLine("searching scripts");
  List<Script> scripts = api.Script
    .WithNameLike("WordPress")
    .WithSharedScope()
    .Limit(1)
    .Find();
  Script script = scripts[0];
  
  // create a disk
  Console.WriteLine("creating a disk");
  Disk disk = api.Disk.Create();
  disk.Name = name;
  disk.Description = description;
  disk.Tags = new List<string> {tag};
  disk.Plan = api.Product.Disk.Ssd;
  disk.Source = archive;
  disk.Save();
  
  // create a server
  Console.WriteLine("creating a server");
  Server server = api.Server.Create();
  server.Name = name;
  server.Description = description;
  server.Tags = new List<string> {tag};
  server.Plan = api.Product.Server
                        .GetBySpec(cpu, mem);
  server.Save();
  
  // connect to shared segment
  Console.WriteLine("connecting the server"+
                       " to shared segment");
  Iface iface = server.AddIface();
  iface.ConnectToSharedSegment();
  
  // wait disk copy
  Console.WriteLine("waiting disk copy");
  if (!disk.SleepWhileCopying()) {
    throw new Exception("failed");
  }
  
  // connect the disk to the server
  Console.WriteLine("connecting the disk");
  disk.ConnectTo(server);
  
  // config the disk
  DiskConfig diskconf = disk.CreateConfig();
  diskconf.HostName = hostName;
  diskconf.Password = password;
  diskconf.SshKey = sshPublicKey;
  diskconf.Scripts.Add(script);
  diskconf.Write();
  
  // boot
  Console.WriteLine("booting the server");
  server.Boot();
  
  // stop
  Thread.Sleep(3);
  Console.WriteLine("stopping the server");
  server.Stop();
  if (!server.SleepUntilDown()) {
    throw new Exception("failed");
  }
  
  // disconnect the disk from the server
  Console.WriteLine("disconnecting the disk");
  disk.Disconnect();
  
  // delete the server
  Console.WriteLine("deleting the server");
  server.Destroy();
  
  // delete the disk
  Console.WriteLine("deleting the disk");
  disk.Destroy();
  
 }
}
