using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Saklient.Cloud;
using Saklient.Cloud.Resources;

class DownloadArchiveExample {
 static void Main(string[] args) {
  
  // settings
  string token = args[0];
  string secret = args[1];
  string zone = args[2];
  string srcName = "GitLab";
  
  // authorize
  API api = API.Authorize(token,secret,zone);
  
  
  // search the source disk
  List<Disk> disks = api.Disk
    .WithNameLike(srcName)
    .Limit(1)
    .Find();
  Disk disk = disks[0];
  
  // copy the disk to a new archive
  Console.WriteLine("copying the disk "+
                     "to a new archive");
  Archive archive = api.Archive.Create();
  archive.Name = "Copy:" + disk.Name;
  archive.Source = disk;
  archive.Save();
  if (!archive.SleepWhileCopying()) {
    throw new Exception("failed");
  }
  
  // get FTP information
  FtpInfo ftp = archive.OpenFtp().FtpInfo;
  Console.WriteLine("FTP information:");
  Console.WriteLine("  user: "+ftp.User);
  Console.WriteLine("  pass: "+ftp.Password);
  Console.WriteLine("  host: "+ftp.HostName);
  
  // download the archive via FTPS
  Uri uri = new Uri("ftp://"+ftp.HostName+
                             "/archive.img");
  var req = (FtpWebRequest)FtpWebRequest.
                                 Create(uri);
  req.EnableSsl = true;
  req.Credentials = new NetworkCredential
                    (ftp.User, ftp.Password);
  req.Method =
          WebRequestMethods.Ftp.DownloadFile;
  var res =(FtpWebResponse)req.GetResponse();
  var src = res.GetResponseStream();
  var dst = new FileStream("archive.img",
          FileMode.Create, FileAccess.Write);
  src.CopyTo(dst);
  dst.Close();
  src.Close();
  
  // delete the archive after download
  Console.WriteLine("deleting the archive");
  archive.CloseFtp();
  archive.Destroy();
  
 }
}
