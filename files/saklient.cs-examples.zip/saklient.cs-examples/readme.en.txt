# How to run examples using saklient.cs


## Visual Studio 2013

1. Create a new project of Visual C# > Console application

2. Replace the new source code with an example file

3. Choose menu > Project > Manage NuGet Packages...

4. Search "Saklient" and install it

5. Build

6. Run the example

   Using 'tk1v'(Sandbox) zone is highly recommended at your first attempt.
   Running these examples in other zones with your API key **MAKES EXPENSES BY YOURSELF**.

    > SET TOKEN=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    > SET SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    > SET ZONE=tk1v
    > create-server.exe %TOKEN% %SECRET% %ZONE%


## Mono


1. Download nuget.exe

    $ wget http://nuget.org/nuget.exe


2. Install packages

    $ mono nuget.exe install -o packages


3. Build

    $ ln -s `find packages -name saklient.dll` ./
    $ mcs -out:create-server.exe -r:saklient.dll create-server.cs


4. Run the example

   Using 'tk1v'(Sandbox) zone is highly recommended at your first attempt.
   Running these examples in other zones with your API key **MAKES EXPENSES BY YOURSELF**.

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ mono create-server.exe "$TOKEN" "$SECRET" "$ZONE"
   
   Some of examples use FTPS connections, but the service is unavailable in the Sandbox zone.
   Please modify the code to skip these processes when running in the Sandbox.  

