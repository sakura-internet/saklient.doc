# saklient.cs を用いたサンプルコードの実行手順


## Visual Studio 2013

1. Visual C# > コンソールアプリケーション の新規プロジェクトを作成します。

2. 新規ソースコードの内容を、サンプルコードのとおりに書き換えます。

3. 「メニュー > プロジェクト > NuGetパッケージの管理...」を開きます。

4. "Saklient" を検索し、インストールします。

5. ビルドします。

6. バイナリを実行します。

   はじめは「tk1v」(Sandbox) ゾーンでの実行を強く推奨します。
   それ以外のゾーンでサンプルコードを実行すると、課金が発生することにご注意ください。

    > SET TOKEN=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
    > SET SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
    > SET ZONE=tk1v
    > create-server.exe %TOKEN% %SECRET% %ZONE%
   
   なお、一部のサンプルコードではFTPS接続を行いますが、Sandboxでは実際には接続できません。
   Sandboxでの実行時は、これらの処理をスキップするように書き換えてください。


## Mono


1. nuget.exe をダウンロードします。

    $ wget http://nuget.org/nuget.exe


2. パッケージをインストールします。

    $ mono nuget.exe install -o packages


3. ビルドします。

    $ ln -s `find packages -name saklient.dll` ./
    $ mcs -out:create-server.exe -r:saklient.dll create-server.cs


4. バイナリを実行します。

   はじめは「tk1v」(Sandbox) ゾーンでの実行を強く推奨します。
   それ以外のゾーンでサンプルコードを実行すると、課金が発生することにご注意ください。

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ mono create-server.exe "$TOKEN" "$SECRET" "$ZONE"

   なお、一部のサンプルコードではFTPS接続を行いますが、Sandboxでは実際には接続できません。
   Sandboxでの実行時は、これらの処理をスキップするように書き換えてください。

