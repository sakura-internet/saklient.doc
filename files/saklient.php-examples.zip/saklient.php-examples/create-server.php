<?php


require_once 'vendor/autoload.php';
use Saklient\Cloud\API;




# settings
$token = $argv[1];
$secret = $argv[2];
$zone = $argv[3];
$name = 'saklient demo';
$description = 'saklient demo';
$tag = 'saklient-test';
$cpu = 1;
$mem = 2;
$hostName = 'saklient-test';
$password = 'C8#mf92mp!*s';
$sshPublicKey = 'ssh-rsa AAAA...';

# authorize
$api = API::authorize
                ($token,$secret,$zone);

# search archives
echo "searching archives\n";
$archives = $api->archive
  ->withNameLike('CentOS 6.5 64bit')
  ->withSizeGib(20)
  ->withSharedScope()
  ->limit(1)
  ->find();
$archive = $archives[0];

# search scripts
echo "searching scripts\n";
$scripts = $api->script
  ->withNameLike('WordPress')
  ->withSharedScope()
  ->limit(1)
  ->find();
$script = $scripts[0];

# create a disk
echo "creating a disk\n";
$disk = $api->disk->create();
$disk->name = $name;
$disk->description = $description;
$disk->tags = [$tag];
$disk->plan = $api->product->disk->ssd;
$disk->source = $archive;
$disk->save();

# create a server
echo "creating a server\n";
$server = $api->server->create();
$server->name = $name;
$server->description = $description;
$server->tags = [$tag];
$server->plan = $api->product->server
              ->getBySpec($cpu, $mem);
$server->save();

# connect to shared segment
echo "connecting the server" .
               " to shared segment\n";
$iface = $server->addIface();
$iface->connectToSharedSegment();

# wait disk copy
echo "waiting disk copy\n";
if (!$disk->sleepWhileCopying()) {
  die('failed');
}

# connect the disk to the server
echo "connecting the disk\n";
$disk->connectTo($server);

# config the disk
$diskconf = $disk->createConfig();
$diskconf->hostName = $hostName;
$diskconf->password = $password;
$diskconf->sshKey = $sshPublicKey;
$diskconf->scripts[] = $script;
$diskconf->write();

# boot
echo "booting the server\n";
$server->boot();

# stop
sleep(3);
echo "stopping the server\n";
$server->stop();
if (!$server->sleepUntilDown()) {
  die('failed');
}

# disconnect the disk from the server
echo "disconnecting the disk\n";
$disk->disconnect();

# delete the server
echo "deleting the server\n";
$server->destroy();

# delete the disk
echo "deleting the disk\n";
$disk->destroy();



