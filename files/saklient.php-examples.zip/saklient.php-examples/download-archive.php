<?php


require_once 'vendor/autoload.php';
use Saklient\Cloud\API;





# settings
$token = $argv[1];
$secret = $argv[2];
$zone = $argv[3];
$srcName = 'GitLab';

# authorize
$api = API::authorize
               ($token,$secret,$zone);

# search the source disk
$disks = $api->disk
  ->withNameLike($srcName)
  ->limit(1)
  ->find();
$disk = $disks[0];

# copy the disk to a new archive
echo "copying the disk ".
                 "to a new archive\n";
$archive = $api->archive->create();
$archive->name = 'Copy:'.$disk->name;
$archive->source = $disk;
$archive->save();
if (!$archive->sleepWhileCopying()) {
  die('failed');
}

# get FTP information
$ftp = $archive->openFtp()->ftpInfo;
echo "FTP information:\n";
echo "  user: ", $ftp->user, "\n";
echo "  pass: ", $ftp->password, "\n";
echo "  host: ", $ftp->hostName, "\n";

# download the archive via FTPS
echo "downloading the archive\n";
$url = 'ftps://' .
  rawurlencode($ftp->user) .':'.
  rawurlencode($ftp->password) .'@'.
  $ftp->hostName . '/archive.img';
$src = fopen($url, 'r');
$dst = fopen('./archive.img', 'w');
stream_copy_to_stream($src, $dst);
fclose($dst);
fclose($src);







# delete the archive after download
echo "deleting the archive\n";
$archive->closeFtp();
$archive->destroy();



