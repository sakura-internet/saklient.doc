# saklient.php を用いたサンプルコードの実行手順


1. Composerをインストールします（まだの場合）。

    $ curl -sS https://getcomposer.org/installer | php
    $ chmod +x composer.phar
    $ mv composer.phar /usr/local/bin/composer


2. Composerのautoloaderをインストールします。

    $ composer install


3. サンプルを実行します。
   
   はじめは「tk1v」(Sandbox) ゾーンでの実行を強く推奨します。
   それ以外のゾーンでサンプルコードを実行すると、課金が発生することにご注意ください。

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ php create-server.php "$TOKEN" "$SECRET" "$ZONE"

   なお、一部のサンプルコードではFTPS接続を行いますが、Sandboxでは実際には接続できません。
   Sandboxでの実行時は、これらの処理をスキップするように書き換えてください。

