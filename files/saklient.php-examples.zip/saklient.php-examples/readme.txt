# How to run examples using saklient.php


1. Install Composer (if not yet)

    $ curl -sS https://getcomposer.org/installer | php
    $ chmod +x composer.phar
    $ mv composer.phar /usr/local/bin/composer


2. Install Composer autoloader

    $ composer install


3. Run examples
   
   Using 'tk1v'(Sandbox) zone is highly recommended at your first attempt.
   Running these examples in other zones with your API key **MAKES EXPENSES BY YOURSELF**.

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ php create-server.php "$TOKEN" "$SECRET" "$ZONE"

