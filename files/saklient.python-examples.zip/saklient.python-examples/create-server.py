#!/usr/local/bin/python3

import sys, time

from saklient.cloud.api import API




# settings
token = sys.argv[1]
secret = sys.argv[2]
zone = sys.argv[3]
name = 'saklient demo'
description = 'saklient demo'
tag = 'saklient-test'
cpu = 1
mem = 2
host_name = 'saklient-test'
password = 'C8#mf92mp!*s'
ssh_public_key = 'ssh-rsa AAAA...'

# authorize
api = API.authorize(token,secret,zone)


# search archives
print('searching archives')
archives = api.archive \
  .with_name_like('CentOS 6.5 64bit') \
  .with_size_gib(20) \
  .with_shared_scope() \
  .limit(1) \
  .find()
archive = archives[0]

# search scripts
print('searching scripts')
scripts = api.script \
  .with_name_like('WordPress') \
  .with_shared_scope() \
  .limit(1) \
  .find()
script = scripts[0]

# create a disk
print('creating a disk')
disk = api.disk.create()
disk.name = name
disk.description = description
disk.tags = [tag]
disk.source = archive
disk.plan = api.product.disk.ssd
disk.save()

# create a server
print('creating a server')
server = api.server.create()
server.name = name
server.description = description
server.tags = [tag]
server.plan = api.product.server \
                 .get_by_spec(cpu, mem)
server.save()

# connect to shared segment
print('connecting the server' +\
                  ' to shared segment')
iface = server.add_iface()
iface.connect_to_shared_segment()

# wait disk copy
print('waiting disk copy')
if not disk.sleep_while_copying():
    raise Exception('failed')


# connect the disk to the server
print('connecting the disk')
disk.connect_to(server)

# config the disk
diskconf = disk.create_config()
diskconf.host_name = host_name
diskconf.password = password
diskconf.ssh_key = ssh_public_key
diskconf.scripts.append(script)
diskconf.write()

# boot
print('booting the server')
server.boot()

# stop
time.sleep(3)
print('stopping the server')
server.stop()
if not server.sleep_until_down():
    raise Exception('failed')


# disconnect the disk from the server
print('disconnecting the disk')
disk.disconnect()

# delete the server
print('deleting the server')
server.destroy()

# delete the disk
print('deleting the disk')
disk.destroy()



