#!/usr/local/bin/python3

import sys, time
from ftplib import FTP_TLS
from saklient.cloud.api import API





# settings
token = sys.argv[1]
secret = sys.argv[2]
zone = sys.argv[3]
src_name = 'GitLab'

# authorize
api = API.authorize(token,secret,zone)


# search the source disk
disks = api.disk \
  .with_name_like(src_name) \
  .limit(1) \
  .find()
disk = disks[0]

# copy the disk to a new archive
print('copying the disk ' +\
                    'to a new archive')
archive = api.archive.create()
archive.name = 'Copy:' + disk.name
archive.source = disk
archive.save()
if not archive.sleep_while_copying():
    raise Exception('failed')


# get FTP information
ftp = archive.open_ftp().ftp_info
print('FTP information:')
print('  user: %s' % ftp.user)
print('  pass: %s' % ftp.password)
print('  host: %s' % ftp.host_name)

# download the archive via FTPS
print('downloading the archive')
ftps = FTP_TLS(ftp.host_name, \
                ftp.user, ftp.password)
ftps.prot_p()
file = open('archive.img', 'wb')
ftps.retrbinary('RETR archive.img', \
                            file.write)
file.close()
ftps.close()








# delete the archive after download
print('deleting the archive')
archive.close_ftp()
archive.destroy()



