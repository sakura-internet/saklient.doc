# saklient.python を用いたサンプルコードの実行手順


1. pipをインストールします（まだの場合）。

    $ easy_install-3.x pip


2. saklientをインストールします。

    $ pip install saklient


3. サンプルを実行します。
   
   はじめは「tk1v」(Sandbox) ゾーンでの実行を強く推奨します。
   それ以外のゾーンでサンプルコードを実行すると、課金が発生することにご注意ください。

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ python3 create-server.py "$TOKEN" "$SECRET" "$ZONE"

   なお、一部のサンプルコードではFTPS接続を行いますが、Sandboxでは実際には接続できません。
   Sandboxでの実行時は、これらの処理をスキップするように書き換えてください。

