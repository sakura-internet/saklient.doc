# How to run examples using saklient.python


1. Install pip (if not yet)

    $ easy_install-3.x pip


2. Install saklient

    $ pip install saklient


3. Run examples
   
   Using 'tk1v'(Sandbox) zone is highly recommended at your first attempt.
   Running these examples in other zones with your API key **MAKES EXPENSES BY YOURSELF**.

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ python3 create-server.py "$TOKEN" "$SECRET" "$ZONE"

