#!/usr/bin/ruby



require 'saklient/cloud/api'




# settings
token = $*[0]
secret = $*[1]
zone = $*[2]
name = 'saklient demo'
description = 'saklient demo'
tag = 'saklient-test'
cpu = 1
mem = 2
host_name = 'saklient-test'
password = 'C8#mf92mp!*s'
ssh_public_key = 'ssh-rsa AAAA...'

# authorize
api = Saklient::Cloud::API::
       authorize(token, secret, zone)

# search archives
puts 'searching archives'
archives = api.archive.
  with_name_like('CentOS 6.5 64bit').
  with_size_gib(20).
  with_shared_scope.
  limit(1).
  find
archive = archives[0]

# search scripts
puts 'searching scripts'
scripts = api.script.
  with_name_like('WordPress').
  with_shared_scope.
  limit(1).
  find
script = scripts[0]

# create a disk
puts 'creating a disk'
disk = api.disk.create
disk.name = name
disk.description = description
disk.tags = [tag]
disk.plan = api.product.disk.ssd
disk.source = archive
disk.save

# create a server
puts 'creating a server'
server = api.server.create
server.name = name
server.description = description
server.tags = [tag]
server.plan = api.product.server.
               get_by_spec(cpu, mem)
server.save

# connect to shared segment
puts 'connecting the server' +
                  ' to shared segment'
iface = server.add_iface
iface.connect_to_shared_segment

# wait disk copy
puts 'waiting disk copy'
disk.sleep_while_copying or
                       abort 'failed'


# connect the disk to the server
puts 'connecting the disk'
disk.connect_to(server)

# config the disk
diskconf = disk.create_config
diskconf.host_name = host_name
diskconf.password = password
diskconf.ssh_key = ssh_public_key
diskconf.scripts.push(script)
diskconf.write

# boot
puts 'booting the server'
server.boot

# stop
sleep 3
puts 'stopping the server'
server.stop
server.sleep_until_down or
                       abort 'failed'


# disconnect the disk from the server
puts 'disconnecting the disk'
disk.disconnect

# delete the server
puts 'deleting the server'
server.destroy

# delete the disk
puts 'deleting the disk'
disk.destroy



