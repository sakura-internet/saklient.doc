#!/usr/bin/ruby



require 'saklient/cloud/api'





# settings
token = $*[0]
secret = $*[1]
zone = $*[2]
src_name = 'GitLab'

# authorize
api = Saklient::Cloud::API::
        authorize(token, secret, zone)

# search the source disk
disks = api.disk.
  withNameLike(src_name).
  limit(1).
  find()
disk = disks[0]

# copy the disk to a new archive
puts 'copying the disk ' +
                    'to a new archive'
archive = api.archive.create
archive.name = 'Copy:' + disk.name
archive.source = disk
archive.save
archive.sleep_while_copying or
                        abort 'failed'


# get FTP information
ftp = archive.open_ftp.ftp_info
puts 'FTP information:'
puts '  user: ' + ftp.user
puts '  pass: ' + ftp.password
puts '  host: ' + ftp.host_name

# download the archive via FTPS
puts 'downloading the archive'

# ...














# delete the archive after download
puts 'deleting the archive'
archive.close_ftp
archive.destroy



