# saklient.ruby を用いたサンプルコードの実行手順


1. saklientをインストールします。

    $ gem install saklient


2. サンプルを実行します。
   
   はじめは「tk1v」(Sandbox) ゾーンでの実行を強く推奨します。
   それ以外のゾーンでサンプルコードを実行すると、課金が発生することにご注意ください。

    $ TOKEN='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
    $ SECRET='xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
    $ ZONE='tk1v'
    $ ruby create-server.rb "$TOKEN" "$SECRET" "$ZONE"

   なお、一部のサンプルコードではFTPS接続を行いますが、Sandboxでは実際には接続できません。
   Sandboxでの実行時は、これらの処理をスキップするように書き換えてください。

